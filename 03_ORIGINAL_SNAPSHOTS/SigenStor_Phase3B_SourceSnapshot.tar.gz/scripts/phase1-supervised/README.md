# SigenStor Phase 1 — Supervised Controller RC2

**Changes:** adds a separately operator-triggered 650 W / 30-second PCS export pilot to RC1. Uses the previously commissioned export sequence: Remote EMS on (`40029=1`), PCS mode (`40031=0`), signed positive watts (`40001=650` as 32-bit), then neutralise `40001=0`, self-consumption `40031=2`, Remote EMS off `40029=0`. Never touches `40034`.

**Installation:** copies scripts only under `/opt/sigenstor/scripts/phase1-supervised`; backs up RC1 in `/opt/sigenstor/data/rtm/checkpoints`; no systemd or Modbus changes. Runs offline mocks. No autonomous timer or dispatch.

**Operator actions:** an export command requires an actual active qualified RC13 `EXPORT` window, matching reserve, exclusive MANUAL authority, live SOC reserve margin, and the active authority web service is temporarily isolated. Any attempted write requires a handback attempt even on ambiguous timeout.

- Read-only RC13/authority state: `python3 -B /opt/sigenstor/scripts/phase1-supervised/rc13_gateway.py`
- Explicit live export (ONLY with operator physically supervising MySigen): `python3 -B /opt/sigenstor/scripts/phase1-supervised/controller.py --execute-30s-export --operator-ack`
- Existing live charge (also explicit only): `python3 -B /opt/sigenstor/scripts/phase1-supervised/controller.py --execute-30s-charge --operator-ack`

**Safety limitation:** no independent outage recovery; a host/network failure during active Remote EMS cannot be corrected by the Python process. No unattended plant writes until separate recovery is qualified. Export pilot is not an autonomous trading controller.

Audit: `/opt/sigenstor/data/rtm/phase1-supervised-audit.jsonl`.
