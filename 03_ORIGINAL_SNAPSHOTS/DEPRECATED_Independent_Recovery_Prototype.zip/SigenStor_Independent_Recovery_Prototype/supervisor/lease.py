"""Independent recovery supervisor lease logic. Simulation only; NO inverter writes."""
import hashlib
import hmac
import json
import math
from dataclasses import dataclass

class LeaseError(ValueError):
    pass

def encode(key: bytes, message: dict) -> bytes:
    payload=json.dumps(message,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    return payload+b'.'+hmac.new(key,payload,hashlib.sha256).hexdigest().encode()

def decode(key: bytes, wire: bytes) -> dict:
    if len(wire)>2048 or len(wire)<70: raise LeaseError('invalid frame length')
    try:
        payload,signature=wire.rsplit(b'.',1)
        expected=hmac.new(key,payload,hashlib.sha256).hexdigest().encode()
        if not hmac.compare_digest(signature,expected): raise LeaseError('authentication failed')
        message=json.loads(payload)
        if not isinstance(message,dict): raise LeaseError('invalid payload')
        return message
    except (UnicodeError,ValueError,TypeError) as e:
        raise LeaseError('invalid frame') from e

@dataclass
class Supervisor:
    key: bytes
    state: str='IDLE'
    session: str | None=None
    sequence: int=-1
    expires: float | None=None
    trip_reason: str | None=None
    max_ttl: float=10.0

    def __post_init__(self):
        if not isinstance(self.key,bytes) or len(self.key)<32: raise LeaseError('requires >=32 byte shared key')

    def receive(self, wire: bytes, now: float):
        """now must be supervisor's monotonic clock, not the sender's wall clock."""
        if not math.isfinite(now): raise LeaseError('invalid clock')
        event=decode(self.key,wire)
        if set(event)!={'v','session','seq','op','ttl'} or event['v']!=1:raise LeaseError('invalid schema')
        sid,seq,op,ttl=event['session'],event['seq'],event['op'],event['ttl']
        if not isinstance(sid,str) or not 8<=len(sid)<=128 or not sid.isascii():raise LeaseError('invalid session')
        if type(seq) is not int or seq<0 or seq>2**63-1:raise LeaseError('invalid sequence')
        if op not in ('ARM','HEARTBEAT'):raise LeaseError('invalid op')
        if type(ttl) not in (float,int) or not math.isfinite(ttl) or not 1<=ttl<=self.max_ttl:raise LeaseError('invalid ttl')
        if self.state=='TRIPPED':raise LeaseError('latched fault: operator recovery required')
        if self.state=='IDLE':
            if op!='ARM':raise LeaseError('first message must arm')
            if seq!=0:raise LeaseError('initial sequence must be zero')
            self.session=sid
        else:
            if sid!=self.session:raise LeaseError('different session')
            if seq<=self.sequence:raise LeaseError('replay or reorder')
            if self.expires is not None and now>=self.expires:
                self.trip('LEASE_EXPIRED')
                raise LeaseError('lease already expired')
            if op!='HEARTBEAT':raise LeaseError('re-arm denied')
        self.sequence=seq
        self.expires=now+ttl
        self.state='ARMED'

    def tick(self, now: float):
        if not math.isfinite(now):raise LeaseError('invalid clock')
        if self.state=='ARMED' and self.expires is not None and now>=self.expires:
            self.trip('LEASE_EXPIRED')
        return self.state

    def trip(self, reason: str):
        self.state='TRIPPED'
        self.trip_reason=reason
        # This software only signals recovery. It cannot recover the inverter.

    def reset(self, *_args, **_kwargs):
        raise LeaseError('reset not implemented: needs independently verified plant handback and operator clearance')
