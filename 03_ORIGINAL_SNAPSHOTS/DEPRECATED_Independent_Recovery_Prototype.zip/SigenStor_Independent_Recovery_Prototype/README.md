# SigenStor independent recovery supervisor — OFFLINE PROTOTYPE

**Status: NOT COMMISSIONED. NO NETWORK LISTENER, NO MODBUS, NO LIVE RECOVERY.**

This is a stand-alone lease-state test artifact intended for a physically independent supervisor platform. Do **not** deploy it in Thor as evidence of independent recovery; a second LXC/VM on the same Proxmox host is not independent of its host/power/network failures.

## What is implemented

- Authenticated HMAC-SHA256 frames with strict schema, session binding and monotonic sequence enforcement.
- Expiring lease based on the supervisor's own monotonic clock (rather than Thor's wall clock).
- Latched `TRIPPED` state on lease expiry; late/replayed frames cannot reactivate it.
- Explicitly unimplemented recovery and latch-clearance paths. No direct Modbus implementation or network listener.
- Unit tests for replay, wrong session, expiry, impossible TTL, malformed frames, and no write API.

**Important**: HMAC authentication does not prevent a compromised Thor from transmitting false healthy heartbeats. It only prevents unauthenticated frames and simple replay. An authenticated heartbeat must eventually be integrated with the independently commissioned plant-state observer, recovery-only writer and operator-authorised armed-session protocol.

## Offline tests

Run `python3 -B -m unittest discover -s tests -v` from the extracted top directory.

## Required physical design decisions before live development

1. Separate physical computer and power feed (prefer a small Linux SBC with its own UPS).
2. Independent wired route to inverter that survives the defined Thor/LXC/network fault domain. A common failed switch may break both paths.
3. Recovery-only writer with command allowlist and read-back (`40001=0`, `40031=2`, `40029=0`) and never write `40034`.
4. Exclusive authority arbitration with Thor, including split-brain, ambiguous writes and power/network partitions.
5. Independent recovery acceptance: fault injection for loss of LXC, Thor, both control routes, delayed/duplicated heartbeats, supervisor reboot, conflicting writer; measured detection/handback latency.
6. Signed, session-bound recovery attestation consumed by RC22, operator acknowledgement, no implicit rearm.

## Release hold

No live inverter writes or full-duration trade sessions are permitted by this prototype. The tested session lease algorithm is only a software component and **cannot recover the plant on its own**.
