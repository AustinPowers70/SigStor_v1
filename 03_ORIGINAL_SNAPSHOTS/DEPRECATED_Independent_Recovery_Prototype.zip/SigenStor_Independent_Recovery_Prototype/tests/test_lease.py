import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'supervisor'))
from lease import Supervisor, LeaseError, encode
KEY=b'K'*32

def frame(op='ARM',seq=0,sid='session-001',ttl=5,**extra):
    p={'v':1,'session':sid,'seq':seq,'op':op,'ttl':ttl}
    p.update(extra)
    return encode(KEY,p)

class Tests(unittest.TestCase):
    def setUp(self):self.s=Supervisor(KEY)
    def test_arm(self):
        self.s.receive(frame(),10);self.assertEqual(self.s.state,'ARMED')
    def test_lease_expiry_latched(self):
        self.s.receive(frame(),10);self.assertEqual(self.s.tick(15),'TRIPPED');self.assertEqual(self.s.trip_reason,'LEASE_EXPIRED')
    def test_refresh(self):
        self.s.receive(frame(),10);self.s.receive(frame('HEARTBEAT',1),13);self.assertEqual(self.s.tick(15),'ARMED')
    def test_replay_rejected(self):
        self.s.receive(frame(),10)
        with self.assertRaises(LeaseError):self.s.receive(frame(),11)
    def test_other_session_rejected(self):
        self.s.receive(frame(),10)
        with self.assertRaises(LeaseError):self.s.receive(frame('HEARTBEAT',1,'session-999'),11)
    def test_late_heartbeat_trips(self):
        self.s.receive(frame(),10)
        with self.assertRaises(LeaseError):self.s.receive(frame('HEARTBEAT',1),16)
        self.assertEqual(self.s.state,'TRIPPED')
    def test_bad_mac(self):
        with self.assertRaises(LeaseError):self.s.receive(frame()[:-1]+b'0',10)
    def test_schema_extra(self):
        with self.assertRaises(LeaseError):self.s.receive(frame(x=7),10)
    def test_ttl_oversized(self):
        with self.assertRaises(LeaseError):self.s.receive(frame(ttl=11),10)
    def test_ttl_zero(self):
        with self.assertRaises(LeaseError):self.s.receive(frame(ttl=0),10)
    def test_missing_arm(self):
        with self.assertRaises(LeaseError):self.s.receive(frame('HEARTBEAT'),10)
    def test_rearm(self):
        self.s.receive(frame(),10)
        with self.assertRaises(LeaseError):self.s.receive(frame('ARM',1),11)
    def test_latched_cannot_arm(self):
        self.s.receive(frame(),10);self.s.tick(16)
        with self.assertRaises(LeaseError):self.s.receive(frame('ARM',0,'session-002'),17)
    def test_reset_not_implemented(self):
        with self.assertRaises(LeaseError):self.s.reset()
    def test_key_length(self):
        with self.assertRaises(LeaseError):Supervisor(b'123')
    def test_no_modbus_functions(self):
        import lease
        s=Path(lease.__file__).read_text()
        for token in ('pymodbus','write_register','socket','40034'):
            self.assertNotIn(token,s)
if __name__=='__main__':unittest.main()
