# SigenStor Phase 3B RC16 — Commissioning transport staging

RC15 accepted on Thor: 196 tests. This bundle adds a restrictive Modbus register
adapter with audited write intent, uncertain-write classification, and full
simulated charge/export and zero-PCS handback transactions. The commissioning
transport harness explicitly rejects live plant connections.

**This is not an authorised live session controller.** There is no live-execution
entry point, no autonomous timer and no change to the frozen RC13 optimiser.
The RC13 feed is research-only, not a dispatch permit. No independent host-loss
recovery has been qualified. Never extend the 30-second commissioned pilots to
a full tariff slot until bounded live expiry/handback failure mode is agreed.

Installer checks manifest and tests before installing separately. No services
or Modbus actions are invoked. `/opt/sigenstor/scripts/phase3b-supervised-rc15`
remains available for rollback. No register 40034 write is permitted.

Next acceptance: a single operator-authorised commissioning test with real
power sampling, strict slot expiry, and verified handback. The live bridge is
intentionally not enabled by this package.
