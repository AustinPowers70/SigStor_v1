#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc16
[[ -d "$TARGET/controller" ]] || exit 2
rm -rf -- "$TARGET"
echo 'RC16 removed; RC15 unaffected.'
