# Phase 3B RC9 — validated high-frequency power acquisition

- Bundles unchanged `sigen_telemetry_v4_4_6_5.py` validated power decoder (FC04 30005, 34 registers, unit 247).
- Bounded operator-invoked read-only 1–10 second cadence (default 2 seconds), up to 1800 seconds, append-only fsynced JSONL evidence.
- Captures signed aggregate grid kW (+import/-export), signed battery-port kW (+charge/-discharge), PV, SOC and inferred load.
- Rejects invalid measurements; no interpolation; journal distinguishes battery-port vs aggregate grid measurement. It cannot independently attribute grid energy to battery operation.
- Preserves RC8 / earlier regression coverage, source routines and default no-dispatch. No new services, timers, or Modbus writes.
- **Not a full-slot actuator**; live supervised dispatch and verified physical grid-side allocation remain separate acceptance gates.

For supervised *read-only sampling* after install (no live control), create the data directory if needed and run:

```bash
clear
sudo install -d -m 0750 /opt/sigenstor/data/rtm
sudo python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc9/controller/power_acquisition_rc9.py --seconds 30 --interval-seconds 2
```

Installer verifies checksums and offline tests prior to installing alongside RC8. Never interpret a successful read-only sample as permission to actuate.
