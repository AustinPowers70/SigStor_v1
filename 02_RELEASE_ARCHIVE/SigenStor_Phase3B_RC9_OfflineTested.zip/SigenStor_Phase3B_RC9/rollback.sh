#!/usr/bin/env bash
set -euo pipefail
echo "RC9 installs alongside RC8, with no services or live control modified. Review local files before manual removal."
