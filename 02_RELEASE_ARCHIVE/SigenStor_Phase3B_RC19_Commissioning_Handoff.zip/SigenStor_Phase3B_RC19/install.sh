#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
sha256sum -c SHA256SUMS
python3 -B -m unittest discover -s tests -p 'test_*.py' -q
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc19
if [[ -e "$TARGET" ]]; then echo 'RC19 already installed; refusing overwrite'; exit 2; fi
mkdir -p "$TARGET"
cp -a controller accepted tests RELEASE_NOTES.md COMMISSIONING_HANDOFF.md SHA256SUMS "$TARGET"/
echo 'RC19 installed READ ONLY; no service or Modbus write changes.'
