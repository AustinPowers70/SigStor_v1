#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc19
if [[ -d "$TARGET" && -f "$TARGET/COMMISSIONING_HANDOFF.md" ]]; then
  rm -rf -- "$TARGET"
  echo 'RC19 staging removed. No services or plant state touched.'
else
  echo 'RC19 marker absent; refusing removal' >&2; exit 2
fi
