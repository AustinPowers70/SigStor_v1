# SigenStor Phase 3B RC10 — Qualified observation integration

- Continues RC9 unchanged; adds `controller/qualified_observation_rc10.py`.
- Requires current, matching RC13 + R5/R6 preflight before and during read-only sampling.
- Uses validated FC04 power decoder, bounded 2-second default cadence, append-only records and immutable source fingerprint.
- Stops on stale or changed qualification, expiry, clock jump, invalid telemetry and SOC ceiling.
- **No actuator is connected. No Modbus writes or autonomous dispatch.**
- Aggregate grid readings are not independent proof of battery-attributable grid-side delivery.
- No service units modified. RC9 remains intact.
- Use only after an operator has reviewed the commissioned environment; a qualified slot may not be present.

## Outstanding

Supervised live full-slot actuator and its end-to-end handback/recovery commissioning are not complete. RC10 is not approved for inverter writes.
