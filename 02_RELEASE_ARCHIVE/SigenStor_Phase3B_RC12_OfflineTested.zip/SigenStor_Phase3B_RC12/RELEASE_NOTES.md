# SigenStor Phase 3B RC12 — Integrated authority and observation rehearsal

RC11 verified on Thor (145/145). RC12 combines exclusive single-writer ownership, panel isolation, immutable RC13/R5 qualification checks, bounded repeated power observations, SOC and reserve guards, time/telemetry integrity, and guaranteed attempted handback into **one** deterministic simulated transaction. All prior code is preserved and regression tests included.

**Commissioning status:** simulation-only, no production Modbus actuator or service changes. Grid measurements are aggregate; battery-specific grid-side energy has NOT been verified. Simulated handback failure withholds authority-panel restart for manual recovery. This is NOT permission to run full-slot control. The accepted 30-second pilots are untouched. No independent host-failure recovery qualified. No modification to 40034.

Install from `/tmp/copy-paste/`: `sudo bash SigenStor_Phase3B_RC12/install.sh` after extracting ZIP. Rollback script included.
