#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc7
[[ -d "$TARGET" && ! -L "$TARGET" ]] || { echo 'RC7 not installed'; exit 0; }
rm -rf -- "$TARGET"
echo 'RC7 isolated install removed; RC6 and production unchanged.'
