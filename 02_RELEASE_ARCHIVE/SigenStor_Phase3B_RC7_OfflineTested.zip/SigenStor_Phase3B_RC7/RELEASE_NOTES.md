# Phase 3B RC7 — In-session evidence assessment (READ ONLY)

RC7 extends RC6 with `controller/commissioning_evidence.py` to assess *actual* telemetry rows (rather than claiming interpolated coverage). Samples are read from the existing telemetry SQLite database using query-only connections; no new sampling daemon, Modbus reads/writes or services are introduced. It reports sample counts, exact edge and gap checks, and separately shows battery-port and **aggregate household grid** energies without confusing them for metered battery-to-grid delivery. A positive battery-port assessment is **not** commissioning or grid-side battery delivery verification.

Example after an attended session, substituting actual UTC session boundaries:

```bash
clear
python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc7/controller/commissioning_evidence.py --start-utc 2026-11-01T18:00:00Z --end-utc 2026-11-01T18:30:00Z --action EXPORT
```

Existing five-minute telemetry will normally produce `INSUFFICIENT_IN_SESSION_EVIDENCE`; that is correct. RC13 untouched, execution disabled, existing RC6 retained. This release does not constitute the production actuator.
