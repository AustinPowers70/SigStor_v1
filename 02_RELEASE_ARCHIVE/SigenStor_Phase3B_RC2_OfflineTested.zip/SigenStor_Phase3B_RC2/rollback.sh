#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc2
if [[ ! -d "$TARGET" || -L "$TARGET" ]]; then echo 'RC2 target absent or symlink; no changes';exit 2;fi
if [[ ! -f "$TARGET/controller/integrated_preview.py" ]]; then echo 'Unexpected target; aborting';exit 2;fi
rm -rf -- "$TARGET"
echo 'RC2 removed. Previous RC1 and commissioned supervised controller untouched.'
