#!/usr/bin/env bash
set -euo pipefail
# Strictly non-dispatching installation. Existing RC1/RC2 services remain unchanged.
SRC="$(cd "$(dirname "$0")" && pwd)"
cd "$SRC"
sha256sum -c SHA256SUMS
python3 -B -m unittest discover -s tests -p 'test_*.py' -v
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc2
if [[ -e "$TARGET" || -L "$TARGET" ]]; then echo "Refusing overwrite: $TARGET" >&2; exit 3; fi
install -d -m 0750 "$TARGET/controller" "$TARGET/accepted/phase3a" "$TARGET/accepted/phase2-supervised"
install -m 0640 "$SRC"/controller/*.py "$TARGET/controller/"
install -m 0640 "$SRC"/accepted/phase3a/*.py "$TARGET/accepted/phase3a/"
install -m 0640 "$SRC"/accepted/phase2-supervised/*.py "$TARGET/accepted/phase2-supervised/"
echo "RC2 advisory integration installed: $TARGET/controller/integrated_preview.py"
echo 'NO systemd changes; NO Modbus writes; NO autonomous dispatch.'
