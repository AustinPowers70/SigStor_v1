# SigenStor Phase 3B RC2 — integrated offline advisory candidate

**Status: offline-tested, NOT live-execution qualified.** No automatic or manual full-slot Modbus dispatch path is provided. Explicit `--execute-slot` always returns BLOCKED.

- Bundles original frozen RC13 handoff logic and original supervised RC2 charge/export source (retained for reference; not called by integrated preview).
- Bundles accepted Phase 3A R5 contract, R6 preview, R7/R9 telemetry and R10 session energy implementations unchanged, plus Phase 2 R8/R9/R10/R12 modules.
- Adds cross-check of currently active RC13 slot to immutable R5/R6 grid-side kWh, timing and action; mismatches HOLD.
- Reads existing battery-port SQLite telemetry without creating or updating records; reads existing R5 result (does not recompute the solver).
- Can compute historical battery-port session energy via R10; does not claim it is verified grid-side energy.
- No systemd changes, no MQTT/network writes, no plant writes, no unattended background process. Rollback deletes only the RC2 directory.

## Live readiness gaps (NOT claimed complete)
1. Historical R5/R6 preview is **not** a commissioned live Modbus power-to-grid-side contract; 500 W charge / 650 W export pilots cannot be assumed to deliver requested grid-side kWh.
2. R9/R10 source samples are battery-port samples, commonly 5-minute intervals; high-frequency in-session sampling and independent grid-side measurement still needed.
3. Full-slot execution / slot expiry / real-time reserve guard / verified handback are **not** enabled in this release.
4. RC13 candidate's `ResearchOnly=true` and `OperatorExecutionAllowed=false` must not be relabelled as execution approval.

## On-host read-only usage
```
clear
python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc2/controller/integrated_preview.py
```

R5 expected at `/opt/sigenstor/data/rtm/phase3a-verified-envelope-r5.json`, raw SQLite at `/opt/sigenstor/data/HouseholdTelemetry.sqlite`.
Missing/stale R5 cannot result in execution. Install uses `/tmp/copy-paste/` for staging; installer does not alter running units.

R5 recomputation depends upon Phase3A R1/R2 and pinned RC13 solver, which are NOT present in the source snapshot; the RC2 preview only reads a previously published R5 artifact. Further acceptance requires checking those pinned production sources and a supervised commissioning opportunity.
