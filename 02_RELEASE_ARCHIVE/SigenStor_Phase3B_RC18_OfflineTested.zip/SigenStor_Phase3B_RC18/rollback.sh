#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc18
[[ -d "$TARGET" && -f "$TARGET/RELEASE_NOTES.md" ]] || { echo 'RC18 not installed'; exit 2; }
rm -rf -- "$TARGET"
echo 'RC18 removed. Prior releases untouched.'
