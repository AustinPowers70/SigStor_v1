# Phase 3B RC18 — Real-plant read-only commissioning preflight

RC17 remains the baseline. This release introduces a **manual read-only** preflight connecting to the commissioned Modbus transport. It verifies Remote EMS OFF (40029), self-consumption mode (40031), PCS demand zero (40001), and obtains a live FC04 power sample from the validated decoder. No live actuator or full-slot execution path is enabled.

This is **not** acceptance of live power delivery. Aggregate grid measurements must not be attributed solely to the battery. Host/network loss cannot be independently recovered by software running on the same LXC. Keep manual MySigen supervision and original controller isolation. RC13 optimiser frozen. 40034 never written.

Use after installation: `python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc18/controller/commissioning_preflight_rc18.py --check`. This initiates READ requests, NOT writes. Do not run it while another controller owns Remote EMS.

Next release gate: operator-authorised bounded live session only after an independent safe handback/recovery method is established or a specifically bounded supervised pilot is approved. No autonomous dispatch.
