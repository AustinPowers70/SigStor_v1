# SigenStor Phase 3B RC17 — real transport interface handoff

## Scope
RC17 adds a **real Modbus transport adapter contract** around the accepted RC16 restricted transport, but deliberately exposes no power-command entry point. The new read-only `preview_handback_contract` can evaluate 40029=0, 40031=2 and PCS 40001=0 through an injected, already-connected Modbus client; it does not contact the inverter by itself.

## Acceptance boundary
- RC13 economics remain frozen and research-only. No RC13 output may independently authorise live commands.
- No operator-authenticated, qualified, watchdog-bounded live full-slot execution has been released.
- Do not interpret offline tests as physical power or grid-side energy verification.
- Commissioned 30-second charge/export pilots are not extended by this release.
- Host/LXC/network failure has no independently commissioned remote-EMS recovery; operator monitoring is mandatory during any future approved session.
- The approved register 40034 remains untouched. No services, timers or Modbus writes are enabled by installation.

## What remains for live supervised release
An operator-initiated real session that obtains exclusive single-writer control, verifies manual authority and fresh slot/reserve, isolates the authority panel, enforces continuous telemetry and expiry, executes the allowlisted command sequence, attempts and verifies common handback, and records a durable audit. Specific live session execution still requires explicit operator approval and attendance.
