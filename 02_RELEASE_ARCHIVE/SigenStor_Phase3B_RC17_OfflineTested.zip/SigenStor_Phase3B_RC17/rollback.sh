#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc17
[ -d "$TARGET" ] || exit 0
rm -rf -- "$TARGET"
echo 'RC17 files removed; older releases unchanged.'
