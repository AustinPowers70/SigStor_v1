#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c SHA256SUMS
python3 -B -m unittest discover -s tests -p 'test_*.py' -q
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc17
if [ -e "$TARGET" ]; then echo 'RC17 already present; refusing overwrite'; exit 2; fi
mkdir -p "$TARGET"
cp -a controller accepted RELEASE_NOTES.md SHA256SUMS "$TARGET/"
echo 'RC17 staged READ ONLY; no services or live Modbus changes.'
