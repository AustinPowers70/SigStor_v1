#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc20
if [[ ! -d "$TARGET" || ! -f "$TARGET/COMMISSIONING_GATES_RC20.md" ]]; then
  echo 'RC20 target absent or unexpected; no deletion performed'; exit 2
fi
rm -rf -- "$TARGET"
echo 'RC20 only removed; older controller versions retained.'
