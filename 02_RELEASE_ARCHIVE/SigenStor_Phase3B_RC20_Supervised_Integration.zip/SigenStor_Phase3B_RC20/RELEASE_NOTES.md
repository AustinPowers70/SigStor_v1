# SigenStor Phase 3B RC20 — Consolidated supervised execution core

**Status: OFFLINE-INTEGRATED / LIVE EXECUTION NOT ENABLED.**

Based on RC19. RC13 economic optimiser, accepted R5/R6 setpoint and historical source files remain unchanged. RC20 adds `controller/supervised_session_rc20.py`, a single integrated bounded-session core that can orchestrate a restricted Modbus command sequence through injected collaborators only. It does NOT contain an operable live CLI or an autonomous timer. Commissioned exact limits remain 500 W grid charge and 650 W PCS export. There is no write path to register 40034.

The new core checks operator acknowledgement, manual authority, externally established independent recovery proof, pinned source fingerprint, single writer lock, authority panel isolation, repeatedly checked qualification, repeated recovery liveness, timestamped high-frequency measurements, SOC ceiling / export reserve, 30-minute upper bound and mandatory verified common handback. Uncertain command starts still require handback. The authority panel cannot be restarted if handback verification fails.

The independent supervisor, its authenticated liveness and actual Thor/network-loss recovery are **NOT** yet commissioned. A boolean injected recovery check or offline test cannot establish that proof. Neither the RC19 research-only status nor this software can promote a slot to live authority. Physical battery-attributable grid-side delivery remains unverified. The actual full-duration live session **must remain blocked** until external recovery qualification and separate operator action.

No service or timer changes. Installer only copies files under `/opt/sigenstor/scripts/phase3b-supervised-rc20`; does not connect to the inverter. No command under this release starts inverter control. Rollback removes only this version after operator review.
