#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc3
if [[ ! -d "$TARGET" || -L "$TARGET" || ! -f "$TARGET/controller/bounded_session.py" ]]; then
 echo 'RC3 target not present or not recognised; no action' >&2; exit 2
fi
rm -rf -- "$TARGET"
echo 'RC3 removed. Earlier controllers unchanged.'
