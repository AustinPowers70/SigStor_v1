# SigenStor Phase 3B RC3 — bounded offline supervisor

RC13 optimiser and accepted R5/R6/R9/R10 modules are carried forward unchanged. RC3 adds a bounded full-slot execution **simulation engine** with injectable plant, sample and clock drivers, and an RC3 read-only readiness report. It enforces fresh/consistent RC13-R6 action and grid-side energy comparison, remaining-slot feasibility, bounded 30-minute maximum, repeated qualification, telemetry freshness and SOC thresholds, clock skew checks, mandatory simulated handback on ambiguous start/abort, and audit event callbacks.

## Safety boundary

No production Modbus actuator is connected to the RC3 engine. `--execute-slot` is always blocked. No services or timers are added or altered. No live Modbus writes. No autonomous dispatch. `40034` remains untouched. The accepted Phase 1 supervised 30-second pilots remain separate; do not interpret this package as approval for full-duration live commissioning. Battery-port evidence is NOT independent grid-side battery energy delivery.

## Installation

Extract ZIP into `/tmp/copy-paste/`, then run `sudo bash /tmp/copy-paste/SigenStor_Phase3B_RC3/install.sh`. No existing paths overwritten. The installer verifies SHA256 and regression tests, then installs at `/opt/sigenstor/scripts/phase3b-supervised-rc3/`.

## Read-only readiness

`python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc3/controller/rc3_readiness.py`

An R5 envelope must be fresh (600-second guard); to regenerate with accepted source use `python3 -B /opt/sigenstor/scripts/phase3a/contract_verified_r5.py --publish` with the RC13 source already fresh. Do not change timestamps manually.

## What remains before supervised operational acceptance

Connect and bench-test a **production** supervised full-slot actuator with manual operator approval, exclusive authority, in-session telemetry sampling and fail-closed recovery under real timeout/network loss. Obtain independently verified grid-side physical-energy evidence and complete an attended slot. This RC3 package does NOT claim that milestone.
