#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc4
if [[ ! -d "$TARGET" || -L "$TARGET" || ! -f "$TARGET/controller/rc4_preflight.py" ]]; then
 echo 'RC4 target missing/unrecognised; no action' >&2; exit 2
fi
rm -rf -- "$TARGET"
echo 'RC4 removed; RC3 and commissioned controllers unchanged.'
