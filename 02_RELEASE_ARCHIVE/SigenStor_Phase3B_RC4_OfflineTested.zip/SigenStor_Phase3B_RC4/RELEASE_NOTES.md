# Phase 3B RC4 — supervised-control integration preflight

RC4 is a **read-only** continuation from the proven RC3 checkpoint. RC13 and accepted R5/R6/R9/R10 source copies remain unchanged. It adds a slot commitment accounting module and unified preflight command. It does **not** enable live full-slot plant control.

## Key correction
RC3's `check_slot` compares a whole half-hour energy target against the dwindling remaining slot capacity. That is not a valid continuation test after delivery has begun. RC4 separates full-slot target from outstanding energy and refuses to infer outstanding energy without independently measured grid-side delivery. No historical battery-port reading is mislabelled grid-side proof.

## Gates
- Commissioned limits: charge 0.5 kW; export 0.65 kW. Neither implies measured grid-side power.
- Rejects energy targets exceeding 0.25 kWh charge / 0.325 kWh export per 30-minute interval at those limits.
- R5 freshness/RC13 authority remain unchanged.
- No systemd units installed or modified; no Modbus writes or autonomous dispatch.
- `--execute-slot` is explicitly blocked.
- Existing RC1/RC2/RC3 tests are included and run at installation.

## Read-only preview
`python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc4/controller/rc4_preflight.py`

## Pending before live supervised release
Qualified real-time grid-side meter and evidence contract; explicitly approved full-slot live actuator; fail-safe authority isolation/recovery; live in-session SOC/power measurements; plant-side handback verification; supervised physical test. No endorsement of unattended operation.
