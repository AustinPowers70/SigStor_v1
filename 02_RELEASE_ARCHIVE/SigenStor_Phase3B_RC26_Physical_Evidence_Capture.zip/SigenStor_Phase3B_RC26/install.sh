#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
sha256sum -c SHA256SUMS
# Focus only on the newly introduced physical evidence recorder. RC25's 314 tests passed on Thor.
python3 -B -m unittest discover -s tests -p 'test_rc26.py' -q
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc26
if [[ -e "$TARGET" ]]; then echo 'RC26 already present; refusing overwrite'; exit 2; fi
mkdir -p "$TARGET"
cp -a controller accepted tests *.md SHA256SUMS "$TARGET"/
echo 'RC26 staged: REAL READ-ONLY POWER CAPTURE; NO SERVICES OR MODBUS WRITES.'
