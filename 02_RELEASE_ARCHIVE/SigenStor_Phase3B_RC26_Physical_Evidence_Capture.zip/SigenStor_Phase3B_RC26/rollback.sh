#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc26
if [[ -d "$TARGET" ]]; then echo 'RC26 is standalone staging, no active service to roll back. RC25 retained.'; fi
