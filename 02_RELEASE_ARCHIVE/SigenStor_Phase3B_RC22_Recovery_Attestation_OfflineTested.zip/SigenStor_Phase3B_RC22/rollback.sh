#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc22
[[ -d "$TARGET" ]] || exit 0
rm -rf -- "$TARGET"
echo 'RC22 code removed; operational latch files remain untouched.'
