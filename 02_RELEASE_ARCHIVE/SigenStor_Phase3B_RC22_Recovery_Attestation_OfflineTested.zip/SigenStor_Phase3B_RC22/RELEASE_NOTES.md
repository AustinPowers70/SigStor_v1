# SigenStor Phase 3B RC22 — Recovery attestation commissioning contract

**Status:** OFFLINE-ONLY commissioning integration. No live execution, no services, no inverter writes, no new authority grant. RC13 optimizer frozen.

RC22 adds session-bound external recovery attestation to the RC21 durable latch. The RC21 convenience callback accepting a boolean `True` is deliberately rejected by RC22's attested recovery-latch type. Clearing requires a marker digest and session match, signed-off physical state claims, <=30-second-old timestamp, operator acknowledgement, and a separately supplied external verifier. No supplied external verifier is commissioned, so the package is **not proof** of recovered plant state. RC21 legacy module is retained only to preserve accepted regression tests, not for use as a new live control path.

This closes an API-level gap; it does **not** solve off-host heartbeat expiration, independent power/network failure, system-wide exclusive writer control or full-slot physical acceptance. Those remain separate hard gates. RC22's session entrypoint is blocked by default.
