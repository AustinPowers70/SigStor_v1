#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
sha256sum -c SHA256SUMS
python3 -B -W ignore::ResourceWarning -m unittest discover -s tests -p 'test_*.py' -q
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc22
if [[ -e "$TARGET" ]]; then echo 'RC22 already installed; refusing overwrite'; exit 2; fi
mkdir -p "$TARGET"
cp -a controller accepted tests RELEASE_NOTES.md RECOVERY_DESIGN.md INDEPENDENT_RECOVERY_ACCEPTANCE.md SHA256SUMS "$TARGET"/
echo 'RC22 staged OFFLINE ONLY; no services or Modbus writes.'
