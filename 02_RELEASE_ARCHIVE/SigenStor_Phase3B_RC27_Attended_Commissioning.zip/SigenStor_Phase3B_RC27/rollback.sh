#!/usr/bin/env bash
set -euo pipefail
echo "RC27 rollback: stop using RC27 commissioning CLI; RC26 remains installed. No service alterations."
