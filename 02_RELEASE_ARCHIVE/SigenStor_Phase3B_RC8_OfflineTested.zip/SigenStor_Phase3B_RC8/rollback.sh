#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc8
[[ -d "$TARGET" && ! -L "$TARGET" ]] || { echo 'RC8 not installed'; exit 0; }
rm -rf -- "$TARGET"
echo 'RC8 isolated install removed; RC6 and production unchanged.'
