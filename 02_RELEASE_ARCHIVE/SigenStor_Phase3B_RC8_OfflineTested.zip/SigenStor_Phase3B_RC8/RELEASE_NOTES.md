# Phase 3B RC8 — Bounded read-only SOC acquisition

Adds direct, repeated FC04 Modbus TCP **read-only** sampling of the previously commissioned 30005/34 register block and SOC bytes 18–19. Default 30 seconds at 2-second intervals, explicit maximum duration 1800 seconds. Output is an append-only SOC-only JSONL audit file, with per-read errors and `modbus_writes=0`. No services/timers are enabled. RC13 unchanged.

**Scope limit:** the uploaded source does not include the validated high-frequency battery/grid power decoder. This sampler deliberately records `battery_kw: null` and `grid_kw: null`, so RC7's power/energy commissioning assessor cannot falsely accept these readings. Operator must not treat SOC readings as power confirmation. Full-slot actuator remains blocked, no independent recovery is commissioned.

Manually start read-only 30-second SOC capture (in an appropriate operating window):

```bash
clear
python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc8/controller/soc_acquisition_rc8.py --seconds 30 --interval-seconds 2
```

This makes read-only Modbus connections but never writes inverter registers. If remote reads are undesirable, simply do not run it. RC7 remains installed for rollback.
