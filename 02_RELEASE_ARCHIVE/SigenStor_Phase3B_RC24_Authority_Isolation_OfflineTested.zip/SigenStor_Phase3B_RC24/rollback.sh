#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' 'RC24 staging has no services or active writers. Retain the prior RC23 tree as rollback baseline.'
