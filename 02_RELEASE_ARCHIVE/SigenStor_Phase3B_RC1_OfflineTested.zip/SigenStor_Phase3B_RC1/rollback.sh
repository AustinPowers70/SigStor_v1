#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc1
if [[ ! -d "$TARGET" ]]; then echo 'Not installed'; exit 0; fi
# Intentionally does not restore/restart authority services or issue Modbus writes.
rm -f -- "$TARGET"/{controller,rc13_gateway,supervised_charge,supervised_export,slot_supervisor}.py
rmdir -- "$TARGET"
echo 'Phase 3B files removed; baseline RC2 unchanged.'
