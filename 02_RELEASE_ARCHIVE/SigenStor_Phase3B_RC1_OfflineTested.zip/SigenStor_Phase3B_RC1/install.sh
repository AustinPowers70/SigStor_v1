#!/usr/bin/env bash
set -euo pipefail
# No installation-side Modbus calls, daemon changes, or service restarts.
BASE=/opt/sigenstor/scripts
STAGE=/tmp/copy-paste
mkdir -p "$STAGE"
SRC="$(cd "$(dirname "$0")" && pwd)"
python3 -B -m unittest discover -s "$SRC/tests" -p 'test_*.py' -v
TARGET="$BASE/phase3b-supervised-rc1"
if [[ -e "$TARGET" ]]; then echo "Refusing overwrite: $TARGET" >&2; exit 3; fi
install -d -m 0750 "$TARGET"
install -m 0640 "$SRC"/controller/*.py "$TARGET"/
echo "Installed read-only Phase 3B slot preview: $TARGET/slot_supervisor.py"
echo 'No units changed; no control enabled; original RC2 untouched.'
