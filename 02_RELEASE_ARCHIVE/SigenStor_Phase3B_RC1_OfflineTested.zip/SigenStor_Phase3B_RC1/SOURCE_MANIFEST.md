# Source provenance
- `controller/controller.py`, `rc13_gateway.py`, `supervised_charge.py`, `supervised_export.py`: copied unmodified from uploaded `SigenStor_Phase3B_SourceSnapshot.tar.gz`.
- `slot_supervisor.py`, tests, installation assets: newly authored for this candidate.
- Source JSON is intentionally not included to avoid deploying a stale RC13 snapshot; actual live data is read from `/opt/sigenstor/data/`.
