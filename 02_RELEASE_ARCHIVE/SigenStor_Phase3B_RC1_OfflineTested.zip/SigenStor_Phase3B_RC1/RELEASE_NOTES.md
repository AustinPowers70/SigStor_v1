# SigenStor Phase 3B — RC1 integration candidate

**Status: OFFLINE TESTED / NOT LIVE COMMISSIONED.** RC13 logic copied byte-for-byte, not modified. Existing RC2 charge/export 30-second paths copied unchanged for reference and regression; no automatic dispatcher or new full-slot Modbus control is enabled.

## Included
- Immutable snapshot of RC2 plant control and RC13 gateway
- New read-only Phase 3B slot preview: selected action, slot expiry, remaining seconds, energy feasibility at previously commissioned 0.5 kW charge / 0.65 kW export pilot setpoints
- Offline regression tests, isolated install, rollback, SHA256 checksums

## Missing gates (not present in supplied snapshot)
1. Accepted R5 grid-side power/energy setpoint interface or its original module, including whether 500 W charge is correct for scheduled grid-energy delivery
2. R9/R10 telemetry adapter and reconciliation implementation for high-frequency *in-session* sampling, with verified grid-side meter energy direction
3. Acceptance evidence from an operator-supervised real half-hour slot and independent plant state observation

Full-slot live execution is deliberately blocked until those interfaces are integrated and tested. A live half-hour trading controller cannot safely be inferred from the RC2 30-second pilot and 5-minute telemetry alone.

## Install (non-dispatching)
Extract ZIP under `/tmp/copy-paste/`, then `sudo bash /tmp/copy-paste/SigenStor_Phase3B_RC1/install.sh`.
Preview: `python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc1/slot_supervisor.py`.
The installer does not overwrite `phase1-supervised`, start a service, change a timer, or perform any Modbus write. The preview reads installed RC13, reserve and authority state; absence/staleness fails closed.

Rollback: `sudo bash /tmp/copy-paste/SigenStor_Phase3B_RC1/rollback.sh`.

**Safety:** do not treat this build as authorisation for unattended or full-slot live dispatch. Keep manual MySigen supervision, existing lock/authority isolation and verified handback. Register 40034 must remain unchanged. Physical grid-side energy not verified by this package.
