#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc5
if [[ ! -d "$TARGET" || -L "$TARGET" || ! -f "$TARGET/controller/rc5_preflight.py" ]]; then
 echo 'RC5 target missing or unrecognised; refusing removal' >&2; exit 2
fi
rm -rf -- "$TARGET"
echo 'RC5 removed. RC4 and commissioned controllers unaffected.'
