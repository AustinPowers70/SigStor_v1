# Phase 3B RC5 — Offline supervised integration seam

RC4 passed 64 tests on Thor. RC5 adds `session_integration_rc5.py` and `rc5_preflight.py` to bind accepted RC13/R5/R6 read-only qualification to a **simulation-only** bounded session lifecycle. Source fingerprinting detects changed source across session checks, and injected telemetry demonstrates abort, reserve, SOC and simulated handback behavior. The previously accepted Modbus pilot code is bundled **unchanged**, not invoked.

**Important:** No production full-slot actuator is implemented or authorised. The accepted 30-second charge/export pilots cannot simply be extended to 30 minutes. Full-slot live commissioning still requires an explicitly approved, independently reviewed live adapter, exclusive authority, appropriate sample cadence and verified handback. Battery-port samples are not independently verified grid-side battery energy. Existing RC13 economics remain frozen.

Install separately as `/opt/sigenstor/scripts/phase3b-supervised-rc5`. No systemd changes, no Modbus writes, no autonomously scheduled jobs. Installer verifies manifest and runs offline regressions. Rollback removes only this isolated RC5 directory.

Read-only preflight: `python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc5/controller/rc5_preflight.py`
