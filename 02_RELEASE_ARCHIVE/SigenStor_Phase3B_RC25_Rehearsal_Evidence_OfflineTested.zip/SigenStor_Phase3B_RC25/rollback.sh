#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' 'RC25 is staged-only. RC24 remains intact for rollback.'
