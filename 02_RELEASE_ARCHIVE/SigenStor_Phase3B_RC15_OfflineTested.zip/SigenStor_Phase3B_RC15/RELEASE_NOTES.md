# Phase 3B RC15 — Integrated simulated plant transaction

RC14 acceptance baseline: 186/186 tests on Thor, no production writes.

RC15 joins the actual commissioned-register **contract** (RC14) to the bounded
RC12 authority-and-telemetry rehearsal through a strictly simulated bridge.
It verifies 500 W charge and 650 W PCS export register sequences, handback,
source-change abort and uncertain-write cleanup within the same transaction.

**Not released:** real Modbus transport, production full-slot dispatch, live
operator approval path, external recovery, and physical grid-side commissioning.
The simulated `PlantSequence` can exercise register-sequence calls on an in-memory
fake only. Do not treat test success as live-authority qualification.

No changes to RC13 economics, systemd services or register 40034.
No autonomous timers or Modbus writes are enabled. Existing RC14 remains intact.
