# SigenStor Phase 3B RC14 — Actuator contract integration candidate

RC13 economic optimisation is frozen. Phase 3A remains formally accepted.

## Engineering change

- Adds `actuator_contract_rc14.py`, a real Modbus register command contract operating **only on injected plant objects**. Real plant adapters cannot be instantiated from its CLI.
- Enforces exactly the commissioned 500 W grid-charge and 650 W PCS-export commands.
- Unifies the intended handback contract: write PCS demand zero, mode 2, Remote EMS off; verify all three, including both PCS words.
- Treats first-write timeouts as uncertain actuation requiring handback.
- Adds a hard-blocked `--execute-slot` entry point and read-only preflight interface.
- Carries the established Phase 3A and Phase 3B source and tests unchanged.

## Operational status

This is a **non-actuating integration candidate**. It has not qualified a production full-duration actuator, host-loss recovery, or independently verified physical grid-side battery delivery. Never deploy it as an unattended controller. No systemd services/timers are changed; no inverter writes are issued by installation or readiness.

Next acceptance gate requires an explicit operator-approved commissioning interface, reliable live qualification/reconciliation and supervised physical tests. No changes to 40034.
