#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc6
[[ -d "$TARGET" && ! -L "$TARGET" ]] || { echo 'RC6 not installed'; exit 0; }
rm -rf -- "$TARGET"
echo 'RC6 isolated install removed; RC5 and production unchanged.'
