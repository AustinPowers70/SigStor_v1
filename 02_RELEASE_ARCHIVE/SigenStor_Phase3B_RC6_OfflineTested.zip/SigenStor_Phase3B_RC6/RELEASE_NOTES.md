# SigenStor Phase 3B RC6 — Evidence boundary hardening (read-only)

Builds upon accepted RC5 and its 77 offline tests. Adds `controller/evidence_rc6.py`, a strictly read-only, optional battery-port evidence recorder with timestamp validation, append-only fsynced JSONL output, refusal of output symlinks, and no Modbus/network control interface. The evidence tool makes **no claim of grid-side verified delivery**.

This release is NOT a production full-slot actuator, and cannot commission a trading slot. RC13 optimiser and commissioned Phase 1 routines remain unchanged. No independent host/network recovery is provided. Install is isolated: no changes to systemd, services, RC5, or plant.

Usage after installing, with an operator-supplied sample JSON containing `valid`, `observed_utc`, `soc_pct`, and `battery_kw`:

`python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc6/controller/evidence_rc6.py --sample-json /path/to/sample.json --out /opt/sigenstor/data/rtm/phase3b-battery-port-evidence.jsonl`

The provided sample must be fresh at invocation; this command is not a sampling daemon. No automatic sampling is configured.
