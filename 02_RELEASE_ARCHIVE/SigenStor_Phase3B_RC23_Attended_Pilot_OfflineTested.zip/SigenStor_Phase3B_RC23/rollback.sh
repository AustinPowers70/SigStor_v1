#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc23
[[ -d "$TARGET" ]] || exit 0
rm -rf -- "$TARGET"
echo 'RC23 removed; durable operational latches, if any, retained.'
