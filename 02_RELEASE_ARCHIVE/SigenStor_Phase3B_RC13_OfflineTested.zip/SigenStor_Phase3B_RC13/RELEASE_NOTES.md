# SigenStor Phase 3B RC13 — Commissioning evidence gate

RC12 has passed 158/158 tests on Thor. RC13 adds a strictly read-only evidence-review gate, with explicit negative gates for authority ownership, RC13 immutability, approved power limits, in-session measurement coverage, reserve limits, and handback audit. The gate never equates aggregate grid power with independently allocated battery-side grid energy. `review_ready` means evidence is suitable for human review; it is **not** plant commissioning, live dispatch permission or Phase 3B supervised operational acceptance.

**Not yet delivered:** production full-slot actuator, real full-duration physical acceptance, or total-host recovery. The existing 30-second pilot routines are not lengthened. Live inverter writes remain unavailable. No service or timer is changed. Register 40034 must remain unchanged.

## Use
`python3 -B /opt/sigenstor/scripts/phase3b-supervised-rc13/controller/commissioning_gate_rc13.py --evidence /path/to/review-evidence.json`

Evidence JSON expects keys `plan`, `samples`, `events`. No execution flag enables the inverter. This is a review interface, not a Modbus bridge.
