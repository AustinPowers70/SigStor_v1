#!/usr/bin/env bash
set -euo pipefail
TARGET=/opt/sigenstor/scripts/phase3b-supervised-rc21
[[ -d "$TARGET" ]] || exit 0
# Do not delete operational recovery latches; those belong outside the package.
rm -rf -- "$TARGET"
echo 'RC21 code removed. No services changed.'
