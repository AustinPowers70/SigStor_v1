# SigenStor Phase 3B RC21 — Durable recovery latch

## Status
Offline-only integration, never a production live controller. No automated dispatch or Modbus writes. RC13 remains frozen.

## Change
RC20 releases its process lock after an uncertain handback; this is necessary for process cleanup but insufficient to prevent a new process acquiring authority. RC21 adds an on-disk recovery-required latch, atomically created and fsynced before any injected session. Failed handback, aborts, process death and uncertain state leave it present. Cooperating RC21 sessions refuse while present. A successful simulated session with verified handback and panel restoration clears it. Manual recovery clearing requires a separately implemented, independently verified physical proof and explicit operator acknowledgement. There is deliberately no CLI to clear the latch.

## Critical limits
- A local latch cannot return an inverter to self-consumption when Thor/LXC/network is unavailable.
- Other controllers not enforcing this latch can still write; actual single-writer enforcement must be integrated across all producers.
- The recovery proof callback is an uncommissioned contract, **not** physical recovery evidence.
- No real plant transport is wired to RC21. No systemd units changed.
- Full-slot commissioning blocked pending independent recovery and supervised commissioning acceptance.
