#!/usr/bin/env bash
set -euo pipefail
echo "RC11 is side-by-side; does not modify services or plant control. Retain RC9 as rollback baseline."
