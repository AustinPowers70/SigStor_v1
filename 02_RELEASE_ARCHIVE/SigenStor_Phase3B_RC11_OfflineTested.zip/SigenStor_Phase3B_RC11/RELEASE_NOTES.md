# SigenStor Phase 3B RC11 — Authority transaction rehearsal

RC10 accepted on Thor (134/134 tests). RC11 adds a *simulation-only* authority transaction that rehearses exclusive lock ownership, authority panel isolation, source/slot requalification, start uncertainty, mandatory simulated handback, panel restoration, and withholding restart on unverified handback. No systemd changes, live actuator, or Modbus writes are introduced.

This is NOT a production full-slot actuator. A complete supervised controller still needs the real commissioned plant-interface adapter, repeated per-sample qualification during active control, watchdog/recovery considerations, and an operator-attended commissioning gate. Independent grid-side physical delivery remains unverified.

Install: `sudo bash SigenStor_Phase3B_RC11/install.sh`; uninstall: inspect and run `rollback.sh`. Stage under `/tmp/copy-paste/`.
